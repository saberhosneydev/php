<!DOCTYPE html>
<html>
<head>
  <title><?php echo e(config('app.name')); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('/css/bulma.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/bulma-extensions.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/index.css')); ?>">
  <script src="<?php echo e(asset('/js/jquery.js')); ?>"></script>
  <script defer src="<?php echo e(asset('/js/fontawesome.js')); ?>"></script>
  <?php echo $__env->yieldContent('customHeader'); ?>
</head>
<body>
  <nav class="navbar" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <a class="navbar-item" href="/">
        <img src="<?php echo e(asset('/imgs/auntlulu.svg')); ?>" alt="Bulma: Free, open source, & modern CSS framework based on Flexbox" width="32" height="32"><span class="has-text-weight-bold"><?php echo e(config('app.name')); ?></span>
      </a>
    </div>

    <div class="navbar-end">
      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">
          <?php echo e(Auth::user()->name); ?>

        </a>

        <div class="navbar-dropdown">
          <a  href="/home/projects" class="navbar-item">
           Dashboard
         </a>
         <hr class="navbar-divider">
         <a class="navbar-item" href="<?php echo e(route('logout')); ?>"
         onclick="event.preventDefault();
         document.getElementById('logout-form').submit();">
         <?php echo e(__('Logout')); ?>

       </a>

       <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
      </form>
    </div>
  </div>
</div>
</nav>

<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('customFooter'); ?>
</body>
</html><?php /**PATH C:\Users\savag\Desktop\sht\resources\views/layouts/projects.blade.php ENDPATH**/ ?>