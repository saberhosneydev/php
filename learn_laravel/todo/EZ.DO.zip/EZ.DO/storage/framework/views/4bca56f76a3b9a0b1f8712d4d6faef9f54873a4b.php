<?php $__env->startSection('content'); ?>
<div class="columns">
	<div class="column is-half is-offset-3">
		<nav class="breadcrumb" aria-label="breadcrumbs">
			<ul>
				<li><a href="/"><?php echo e(config('app.name')); ?></a></li>
				<li><a href="/home">Home</a></li>
				<li><a href="/home/projects">Projects</a></li>
				<li class="is-active"><a href="#" aria-current="page">Create</a></li>
			</ul>
		</nav>
		<form action="<?php echo e(route('projects.store')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="field">
				<input class="input" name="name" type="text" placeholder="Project Name">
			</div>
			<div class="field">
				<button class="button is-info">
					Create
				</button>
			</div>

		</form>
		<div class="field">
			<?php if($errors->any()): ?>
			<div class="is-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="notification is-danger">
						<button class="delete"></button>
						<?php echo e($error); ?>

					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customFooter'); ?>
<script>
	$(document).ready(function() {
		$('.delete').click(function(){
			$('.notification').css("display", "none");
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\savag\Desktop\sht\resources\views/projects/create.blade.php ENDPATH**/ ?>