<?php $__env->startSection('customHeader'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/css/bulma-radio-checkbox.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="columns">
	<div class="column is-10 is-offset-1">
		<div class="field">
			<nav class="breadcrumb" aria-label="breadcrumbs">
				<ul>
					<li><a href="/"><?php echo e(config('app.name')); ?></a></li>
					<li><a href="/home">Home</a></li>
					<li><a href="/home/projects">Projects</a></li>
					<li class="is-active"><a href="/home/projects"><?php echo e($project->name); ?></a></li>
				</ul>
			</nav>
		</div>
		<?php $__currentLoopData = $project->boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="box has-background-white-ter" style="width: 33%;display: inline-block;">
			<div class="content">
				<p class="title is-marginless">
					<?php echo e($board->name); ?>

					<nav class="level is-mobile">
						<div class="level-left">
							<form action="/home/boards/<?php echo e($board->id); ?>" method="POST" id="deleteBoard<?php echo e($board->id); ?>" >
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<a class="level-item" aria-label="reply" onclick="document.getElementById('deleteBoard' + <?php echo e($board->id); ?>).submit()">
									<span class="icon is-small">
										<i class="fas fa-trash" aria-hidden="true"></i>
									</span>
								</a>
							</form>
							<form action="" style="margin-left: 35px;">
								<a class="level-item" aria-label="retweet">
									<span class="icon is-small boardupdateid" id="<?php echo e($board->id); ?>">
										<i class="far fa-edit" aria-hidden="true"></i>
									</span>
								</a>
							</form>
						</div>
					</nav>
				</p>
				<div class="field">
					<form action="/home/boards/<?php echo e($board->id); ?>" method="POST" id="BoardUpdate<?php echo e($board->id); ?>" style="display: none;">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
						<input class="input is-inline" type="text" placeholder="Edit task detail" name="boardEdit" style="width: 65%;">
						<button class="button" class="is-inline">Update</button>
					</form>
				</div>
				<div class="field">
					<?php if($errors->any()): ?>
					<div class="is-danger">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="notification is-danger">
							<button class="delete"></button>
							<?php echo e($error); ?>

						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<?php endif; ?>
				</div>
				<?php if($board->tasks->count()): ?>
				<?php $__currentLoopData = $board->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="box has-ribbon">
					<?php if($task->priorty === "Normal"): ?>
					<div class="ribbon is-info"><?php echo e($task->priorty); ?></div>
					<?php elseif($task->priorty === "Need Focus"): ?>
					<div class="ribbon is-warning"><?php echo e($task->priorty); ?></div>
					<?php else: ?>
					<div class="ribbon is-danger"><?php echo e($task->priorty); ?></div>
					<?php endif; ?>
					<div class="content">
						<div class="field" style="margin-top: 15px;">
							<div class="field">
								<form action="<?php echo e(route('tasks.completed')); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<?php echo method_field('PATCH'); ?>
									<input type="hidden" name="taskId" value="<?php echo e($task->id); ?>">
									<input class="is-checkradio  is-large" id="<?php echo e($task->id); ?>" type="checkbox"  <?php echo e($task->completed === 1 ? "checked" : ""); ?> name="completed" onchange="this.form.submit()">
									<label for="<?php echo e($task->id); ?>" style="font-size: 1.4rem;<?php echo e($task->completed === 1 ? "text-decoration: line-through;" : ""); ?>"><?php echo e($task->name); ?></label>
								</form>
							</div>

							<div class="field">
								<form action="/home/tasks/<?php echo e($task->id); ?>" method="POST" id="TaskUpdate<?php echo e($task->id); ?>" style="display: none;">
									<?php echo csrf_field(); ?>
									<?php echo method_field('PATCH'); ?>
									<input class="input is-inline" type="text" placeholder="Edit task detail" name="taskEdit" style="width: 65%;">
									<button class="button" class="is-inline">Update</button>
								</form>
							</div>
						</div>

					</div>
					<nav class="level is-mobile">
						<form action="/home/tasks/<?php echo e($task->id); ?>" method="POST" id="deleteTask<?php echo e($task->id); ?>">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<a class="level-item" aria-label="reply" onclick="document.getElementById('deleteTask' + <?php echo e($task->id); ?>).submit()">
								<span class="icon is-small">
									<i class="fas fa-trash" aria-hidden="true"></i>
								</span>
							</a>
						</form>
						<form action="">
							<a class="level-item" aria-label="retweet">
								<span class="icon is-small taskupdateid" id="<?php echo e($task->id); ?>">
									<i class="far fa-edit" aria-hidden="true"></i>
								</span>
							</a>
						</form>
						<form action="">
							<a class="level-item" aria-label="like">
								<span class="icon is-small tooltip" data-tooltip="Not functional yet .">
									<i class="fas fa-heart" aria-hidden="true"></i>
								</span>
							</a>
						</form>


					</nav>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				<div class="box">
					<div class="content">
						<form action="<?php echo e(route('tasks.store')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<input type="hidden" name="boardId" value="<?php echo e($board->id); ?>">
							<input type="hidden" name="projectId" value="<?php echo e($board->project->id); ?>">
							<div class="field">
								<input type="text" class="input" name="name" placeholder="task detail">
							</div>
							<div class="field" style="padding-left: 5px;">
								<label class="is-inline has-text-weight-bold" for="prior"  style="position:relative;top: 5px;margin-right: 25px;left: 2px;">Priorty : </label>
								<div class="control has-icons-left is-inline">
									<div class="select">
										<select id="prior" name="priorty">
											<option selected class="has-text-info">Normal</option>
											<option class="has-text-warning">Need Focus</option>
											<option class="has-text-danger">Emergeny</option>
										</select>
									</div>
									<span class="icon is-small is-left">
										<i class="fas fa-exclamation"></i>
									</span>
								</div>

							</div>
							<div class="field">
								<input class="is-checkradio" id="taskCompleted<?php echo e($board->id); ?>" type="checkbox" name="taskCompleted">
								<label for="taskCompleted<?php echo e($board->id); ?>">Is task completed ?</label>
							</div>
							<div class="field">
								<button class="button" style="width: 100%;">Create</button>
							</div>
						</form>

					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<form action="<?php echo e(route('boards.store')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="projectId" value="<?php echo e($project->id); ?>">
			<input class="input" type="text" name="name" placeholder="New board ?" style="width: 50%;">
			<button class="button">Submit</button>
		</form>
		<form action="/home/projects/<?php echo e($project->id); ?>" method="POST" id="DeleteProject">
			<?php echo csrf_field(); ?>
			<?php echo method_field('DELETE'); ?>
			<button class="button tooltip is-tooltip-active is-tooltip-right" data-tooltip="Click to delete" id="DeleteBtn">Delete project</button>
		</form>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customFooter'); ?>
<script>
	$(document).ready(function(){
		$('.taskupdateid').click(function(){
			var id = $(this).attr('id');
			var formId = "TaskUpdate" + id;
			$('#'+ formId).css('display','block');
		});
		$('.boardupdateid').click(function(){
			var id = $(this).attr('id');
			var formId = "BoardUpdate" + id;
			$('#'+ formId).css('display','block');
		});
		$('.delete').click(function(){
			$('.notification').css("display", "none");
		});
		$('#DeleteBtn').click(function(){
			var y;
			var x = prompt("Are you sure ? This action is irreversible ! , Type YES for confirmation.");
			if (x.toLowerCase() == "yes") {
				$("#DeleteProject").submit(function(e){
					return true;
				});
			}else {
				$("#DeleteProject").submit(function(e){
					return false;
				});
				$(this).attr('data-tooltip', "Confirmation Failed, Please refresh and try again");
			}
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\savag\Desktop\Apps\EZ.DO\resources\views/projects/show.blade.php ENDPATH**/ ?>