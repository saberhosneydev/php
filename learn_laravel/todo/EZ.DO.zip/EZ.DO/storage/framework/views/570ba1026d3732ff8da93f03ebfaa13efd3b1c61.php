<?php $__env->startSection('content'); ?>
<div class="columns">
	<div class="column is-8 is-offset-2">
		<nav class="breadcrumb" aria-label="breadcrumbs">
			<ul>
				<li><a href="/"><?php echo e(config('app.name')); ?></a></li>
				<li><a href="/home">Home</a></li>
				<li class="is-active"><a href="/home/projects">Projects</a></li>
			</ul>
		</nav>

		<div class="field">

			<div class="timeline is-centered">
				<header class="timeline-header">
					<span class="tag is-medium is-primary">Start</span>
				</header>
				<?php if(Auth::user()->projects->count()): ?>
				<?php $__currentLoopData = Auth::user()->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="timeline-item is-primary">
					<div class="timeline-marker is-primary"></div>
					<div class="timeline-content">
						<p class="heading"><?php echo e($project->from_date); ?></p>
						<p><a href="/home/projects/<?php echo e($project->id); ?>"><?php echo e($project->name); ?></a></p>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<div class="timeline-item is-primary">
					<div class="timeline-marker is-primary"></div>
					<div class="timeline-content">
						<p class="heading">Upcomning Future.</p>
						<p><a href="#">Yay nothing yet.</a></p>
					</div>
				</div>
				<?php endif; ?>
				<header class="timeline-header">
					<a href="/home/projects/create"><span class="tag is-medium is-info"><i class="fa fa-plus" ></i></span></a>
				</header>
			</div>


		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\savag\Desktop\sht\resources\views/projects/index.blade.php ENDPATH**/ ?>