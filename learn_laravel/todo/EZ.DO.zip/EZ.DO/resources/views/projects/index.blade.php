@extends('layouts.projects')

@section('content')
<div class="columns">
	<div class="column is-8 is-offset-2">
		<nav class="breadcrumb" aria-label="breadcrumbs">
			<ul>
				<li><a href="/">{{ config('app.name') }}</a></li>
				<li><a href="/home">Home</a></li>
				<li class="is-active"><a href="/home/projects">Projects</a></li>
			</ul>
		</nav>

		<div class="field">

			<div class="timeline is-centered">
				<header class="timeline-header">
					<span class="tag is-medium is-primary">Start</span>
				</header>
				@if(Auth::user()->projects->count())
				@foreach (Auth::user()->projects as $project)
				<div class="timeline-item is-primary">
					<div class="timeline-marker is-primary"></div>
					<div class="timeline-content">
						<p class="heading">{{$project->from_date}}</p>
						<p><a href="/home/projects/{{$project->id}}">{{$project->name}}</a></p>
					</div>
				</div>
				@endforeach
				@else
				<div class="timeline-item is-primary">
					<div class="timeline-marker is-primary"></div>
					<div class="timeline-content">
						<p class="heading">Upcomning Future.</p>
						<p><a href="#">Yay nothing yet.</a></p>
					</div>
				</div>
				@endif
				<header class="timeline-header">
					<a href="/home/projects/create"><span class="tag is-medium is-info"><i class="fa fa-plus" ></i></span></a>
				</header>
			</div>


		</div>
	</div>
</div>


@endsection